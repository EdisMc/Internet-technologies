package repositories;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import models.Student;

public class StudentRepository {
	private static StudentRepository instance = null;
	private static Set<Student> students;
	
	private StudentRepository() {
	}
	
	public static StudentRepository getInstance() {
		if (instance == null) {
			instance = new StudentRepository();
			students = new HashSet<Student>();
		}
		return instance;
	}
	
	public boolean addStudent(Student student) {
		return students.add(student);
	}
	
	public Student getStudentByFN(String fn) {
		for (Student s : students) {
			if (s.getfNumber().equals(fn)) {
				return s;
			}
		}
		return null;
	}
	
}


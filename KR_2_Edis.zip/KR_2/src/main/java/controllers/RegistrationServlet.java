package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.Student;
import repositories.StudentRepository;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	StudentRepository repository;
   
    @Override
	public void init(ServletConfig config) throws ServletException {
		repository.getInstance();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/RegStudent.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fNumber = request.getParameter("faculty-number");
		String firstName = request.getParameter("name");
		String lastName = request.getParameter("last-name");
		String group = request.getParameter("group");
		
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		if (fNumber.isEmpty() || fNumber == null || firstName.isEmpty() || firstName == null || 
				lastName.isEmpty() || lastName == null || group.isEmpty() || group == null) {
			out.print("<p> Не сте въвели всички полета! </p>");
			RequestDispatcher rd = request.getRequestDispatcher("/RegStudent.jsp");
			rd.include(request, response);
		} else {
			Student student = new Student(fNumber, firstName, lastName, group);
			if (repository.getStudentByFN(fNumber) == null) {
				repository.addStudent(student);
				//response.sendRedirect("profile");

				HttpSession oldSession = request.getSession(false);
				if (oldSession != null) {
					oldSession.invalidate();
				}
				
				HttpSession newSession = request.getSession();
				newSession.setAttribute("loggedStudent", student);
				
				RequestDispatcher rd = request.getRequestDispatcher("/StudentProfile.jsp");
				rd.forward(request, response);
			} else {
				out.print("<p> Студентът e вече регистриран!</p>");
				RequestDispatcher rd = request.getRequestDispatcher("/RegStudent.jsp");
				rd.include(request, response);
			}
		}
	}

}

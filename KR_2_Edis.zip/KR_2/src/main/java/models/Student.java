package models;

import java.io.Serializable;
import java.util.Objects;

public class Student implements Serializable {
	private String fNumber;
	private String firstName;
	private String lastName;
	private String group; 
	
	public Student() {
	}
	
	public Student(String fNumber, String firstName, String lastName, String group) {
		super();
		this.fNumber = fNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.group = group;
	}

	public String getfNumber() {
		return fNumber;
	}

	public void setfNumber(String fNumber) {
		this.fNumber = fNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	@Override
	public int hashCode() {
		return Objects.hash(fNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student student = (Student) obj;
		return Objects.equals(fNumber, student.fNumber);
	}
	
}
